#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "dialog.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    void buttonClick();
    void ouvrir_dialog();

private:
    Ui::MainWindow *ui;
    Dialog *dialog;
};


#endif // MAINWINDOW_H


