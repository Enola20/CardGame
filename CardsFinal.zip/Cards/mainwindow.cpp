#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QWidget>
#include <QPushButton>
#include "secondpage.h"
#include <QMenuBar>
#include <QAction>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), dialog(new Dialog)
{
    ui->setupUi(this);

    // Connect actions to slots
    connect(ui->Quitter, &QAction::triggered, this, &MainWindow::close);
    connect(ui->regles_de_jeu, &QAction::triggered, this, &MainWindow::ouvrir_dialog);
    connect(ui->Play, &QPushButton::clicked, this, &MainWindow::buttonClick);
}

void MainWindow::ouvrir_dialog() {
    dialog->open();
}

void MainWindow::buttonClick() {
    secondPage *pageSuivante = new secondPage(this);
    pageSuivante->showMaximized();
   // this->update();
}
