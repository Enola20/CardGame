#ifndef PLAYER_H
#define PLAYER_H

#include <QVector>
#include "card.h"
#include <QString>

class player
{
public:
    player(int score);
    int getScore();

private:

    int score;
};

#endif // PLAYER_H
