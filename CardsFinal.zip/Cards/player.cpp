#include "player.h"

player::player(int score) : score(score){}
player::getScore(){
    return score;
}
