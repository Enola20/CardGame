#include "Card.h"
#include <QString>

Card::Card(){};
Card::Card(QString type, int card_num, QString path)
    : type(type), card_num(card_num), path(path) {};

Card::Card(const Card& other)
    : type(other.type), card_num(other.card_num), path(other.path){}
QString Card::getType() {
    return type;
}

int Card::getNumber() {
    return card_num;
}

QString Card::getPath(){
    return path;
}


Card& Card::operator=(const Card& other) {
    if (this != &other) {
        type = other.type;
        card_num = other.card_num;
        path = other.path;
    }
    return *this;
}
