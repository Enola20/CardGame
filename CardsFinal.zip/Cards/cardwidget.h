#ifndef CARDWIDGET_H
#define CARDWIDGET_H

#include <QObject>
#include <QString>
#include <QLabel>
#include "card.h"

class cardWidget : public QObject
{
    Q_OBJECT
public:
    explicit cardWidget(QObject *parent = nullptr);

signals:

};

#endif // CARDWIDGET_H
