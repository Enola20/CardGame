#ifndef LEVEL_H
#define LEVEL_H
#include <QString>
#include <QWidget>
#include <QMainWindow>

namespace Ui {
class level;
}

class level : public QMainWindow
{
    Q_OBJECT

public:
    level(QWidget *parent = 0);
    ~level();
    void getLevel();
    void buttonClick();

private:
    Ui::level *ui;
    QString niveau;
};

#endif // LEVEL_H
