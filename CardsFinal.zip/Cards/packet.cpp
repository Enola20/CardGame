#include "card.h"
#include <QVector>
#include "packet.h"
#include <algorithm>
#include <random>
#include "player.h"
#include "playerpacket.h"
#include <QPropertyAnimation>
#include <QString>


Packet::Packet(){
    cards.push_back(Card("Copas",1,":/image/30.gif"));
    cards.push_back(Card("Copas",2,":/image/31.gif"));
    cards.push_back(Card("Copas",3,":/image/32.gif"));
    cards.push_back(Card("Copas",4,":/image/33.gif"));
    cards.push_back(Card("Copas",5,":/image/34.gif"));
    cards.push_back(Card("Copas",6,":/image/35.gif"));
    cards.push_back(Card("Copas",7,":/image/36.gif"));
    cards.push_back(Card("Copas",10,":/image/37.gif"));
    cards.push_back(Card("Copas",11,":/image/38.gif"));
    cards.push_back(Card("Copas",12,":/image/39.gif"));
    cards.push_back(Card("Sword",1,":/image/20.gif"));
    cards.push_back(Card("Sword",2,":/image/21.gif"));
    cards.push_back(Card("Sword",3,":/image/22.gif"));
    cards.push_back(Card("Sword",4,":/image/23.gif"));
    cards.push_back(Card("Sword",5,":/image/24.gif"));
    cards.push_back(Card("Sword",6,":/image/25.gif"));
    cards.push_back(Card("Sword",7,":/image/26.gif"));
    cards.push_back(Card("Sword",10,":/image/27.gif"));
    cards.push_back(Card("Sword",11,":/image/28.gif"));
    cards.push_back(Card("Sword",12,":/image/29.gif"));
    cards.push_back(Card("Coin",1,":/image/00.gif"));
    cards.push_back(Card("Coin",2,":/image/01.gif"));
    cards.push_back(Card("Coin",3,":/image/02.gif"));
    cards.push_back(Card("Coin",4,":/image/03.gif"));
    cards.push_back(Card("Coin",5,":/image/04.gif"));
    cards.push_back(Card("Coin",6,":/image/05.gif"));
    cards.push_back(Card("Coin",7,":/image/06.gif"));
    cards.push_back(Card("Coin",10,":/image/07.gif"));
    cards.push_back(Card("Coin",11,":/image/08.gif"));
    cards.push_back(Card("Coin",12,":/image/09.gif"));
    cards.push_back(Card("Bat",1,":/image/10.gif"));
    cards.push_back(Card("Bat",2,":/image/11.gif"));
    cards.push_back(Card("Bat",3,":/image/12.gif"));
    cards.push_back(Card("Bat",4,":/image/13.gif"));
    cards.push_back(Card("Bat",5,":/image/14.gif"));
    cards.push_back(Card("Bat",6,":/image/15.gif"));
    cards.push_back(Card("Bat",7,":/image/16.gif"));
    cards.push_back(Card("Bat",10,":/image/17.gif"));
    cards.push_back(Card("Bat",11,":/image/18.gif"));
    cards.push_back(Card("Bat",12,":/image/19.gif"));
    shuffle(cards);
    shuffle(cards);
}



QVector<Card> Packet::getCards() {
    return cards;
}

void Packet::shuffle(QVector<Card>& cards) {
    for (int i = 0; i < cards.size(); ++i) {
        int r = i + (rand() % (cards.size() - i));
        std::swap(cards[i], cards[r]);
    }
}
