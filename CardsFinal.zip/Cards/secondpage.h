#ifndef SECONDPAGE_H
#define SECONDPAGE_H

#include <QMainWindow>
#include <QVector>
#include "Card.h"
#include "Packet.h"
#include <QFrame>
#include "win.h"
#include "lose.h"
#include "draw.h"


namespace Ui {
class secondPage;
}

class secondPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit secondPage(QWidget *parent = nullptr);
    ~secondPage();
    void clickeBoutton(QPushButton* boutton,int Index, QPushButton* nextB, QPushButton* bouttonA, QPushButton* nextA, int scoreU, int scoreA);
    void hide(QPushButton* buttonA, QPushButton* buttonP);
    void move(QPushButton* buttonA, QPushButton* buttonP, int Index, int scoreU, int scoreA);
    void generateTimer(QPushButton* buttonA, QPushButton* buttonB,int index, int scoreU, int scoreA);

    void bravo();
    void gameOver();
    void tie();


private:
    Ui::secondPage *ui;
    Win* wiin;
    Lose* lose;
    Draw* Tie;

};

#endif // SECONDPAGE_H
