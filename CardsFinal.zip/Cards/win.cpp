#include "win.h"
#include "ui_win.h"
#include "secondpage.h"
#include "mainwindow.h"

Win::Win(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Win)
{
    ui->setupUi(this);

    connect(ui->quitter, &QPushButton::clicked, this, &Win::close);
}

Win::~Win()
{
    delete ui;
}


