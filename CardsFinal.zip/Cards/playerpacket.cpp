// PlayerPacket.cpp
#include "PlayerPacket.h"
#include "card.h"
#include "player.h"
#include "secondpage.h"
#include "ui_secondpage.h"


Card PlayerPacket::drawCard() {
    // Draw the top card from the player's packet
    if (!isEmpty()) {
        // Retrieve the top card from the packet
        Card drawnCard = inHand.back();

        // Remove the top card from the packet
        inHand.pop_back();

        // Return the drawn card
        return drawnCard;
    } else {
        // Handle the case when the packet is empty
        // For now, returning a default-constructed card
        // You might want to handle this differently based on game rules
        return Card("",0, "");
    }
}

bool PlayerPacket::isEmpty() const {
    return inHand.isEmpty();
}
