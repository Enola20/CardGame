#ifndef PACKET_H
#define PACKET_H

#include "card.h"
#include <QVector>

class Packet
{
public:
    Packet();
    QVector<Card> getCards();
    void distribute(QVector<Card>& player1, QVector<Card>& player2);
    void shuffle(QVector<Card>& packet);
    //void addCardToHand(Card& carte);

private:
    QVector<Card> cards;


};

#endif // PACKET_H
