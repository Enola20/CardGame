#include "secondpage.h"
#include "ui_secondpage.h"
#include <QPropertyAnimation>
#include <QPoint>
#include "packet.h"
#include <QtWidgets>
#include <QIcon>
#include <QtCore>
#include <QtGui>
#include <QDebug>
#include <player.h>

QVector<Card> playerUser;
QVector<Card> playerAI;
Packet packet;
QVector<Card> allCards = packet.getCards();

secondPage::secondPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::secondPage), wiin(new Win), lose(new Lose), Tie(new Draw)
{

    ui->setupUi(this);

    player user(0);
    player AI(0);
    int scoreU = user.getScore();
    int scoreA = AI.getScore();

    for (int i = 1; i <= 20; ++i) {
        int Index = i;

            QString buttonNameP = QString("player_%1").arg(i, 2, 10, QChar('0'));
            QPushButton *playerButton = this->findChild<QPushButton*>(buttonNameP);
            playerButton->setStyleSheet("image: url(:/image/backcard.png);");
            QString nextbuttonNameP = QString("player_%1").arg((i+1), 2, 10, QChar('0'));
            QPushButton *nextButtonP = this->findChild<QPushButton*>(nextbuttonNameP);

            QString buttonNameA = QString("AI_%1").arg(i+20, 2, 10, QChar('0'));
            QPushButton *AIButton = this->findChild<QPushButton*>(buttonNameA);
            AIButton->setStyleSheet("image: url(:/image/backcard.png);");
            QString nextbuttonNameA = QString("AI_%1").arg((i+20+1), 2, 10, QChar('0'));
            QPushButton *nextButtonA = this->findChild<QPushButton*>(nextbuttonNameA);

        if (playerButton) {
            connect(playerButton, &QPushButton::clicked,this, [=]() {
                clickeBoutton(playerButton,Index, nextButtonP, AIButton, nextButtonA, scoreU, scoreA);
            });
        } else {
            qDebug() << "Button not found: " << buttonNameP;
        }
    }

    int scorePfinal = ui->scoreP->intValue();
    int scoreAfinal = ui->scoreAI->intValue();

    if(scorePfinal > scoreAfinal){
        bravo();
    } else if(scorePfinal < scoreAfinal){
        gameOver();
    } else {
        tie();
    }
}

secondPage::~secondPage()
{
    delete ui;
}

void secondPage::clickeBoutton(QPushButton* boutton,int Index, QPushButton* nextB, QPushButton* bouttonA, QPushButton* nextA, int scoreU, int scoreA){

    QString image = allCards[Index].getPath();
    QString styleSheet = "image: url(" + image + ");";
    boutton->setStyleSheet(styleSheet);
    nextB->setStyleSheet("image: url(:/image/backcard.png);");

    QString imageA = allCards[Index + 20].getPath();
    QString styleSheetA = "image: url(" + imageA + ");";
    bouttonA->setStyleSheet(styleSheetA);
    nextA->setStyleSheet("image: url(:/image/backcard.png);");

    QPropertyAnimation* animation = new QPropertyAnimation(boutton,"geometry");
    animation->setStartValue(boutton->geometry());
    animation->setEndValue(QRect(530, 320, boutton->width(), boutton->height()));
    animation->setDuration(1000);
    animation->start();

    QPropertyAnimation* animationA = new QPropertyAnimation(bouttonA,"geometry");
    animationA->setStartValue(bouttonA->geometry());
    animationA->setEndValue(QRect(530, 200, bouttonA->width(), bouttonA->height()));
    animationA->setDuration(1000);
    animationA->start();

    connect(animation, &QPropertyAnimation::finished,this,[=]() {
        this->generateTimer(bouttonA, boutton, Index, scoreU, scoreA);
    });

}

void secondPage::generateTimer(QPushButton* buttonA, QPushButton* buttonB, int index, int scoreU, int scoreA){
    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout,this, [=]() {
        this->move(buttonA, buttonB, index, scoreU, scoreA); // Call a function to start another animation
        timer->stop(); // Stop the timer
    });
    timer->start(500); // Start the timer after 500 milliseconds
}

void secondPage::move(QPushButton* bouttonA, QPushButton* bouttonP, int Index, int scoreU, int scoreA){

    scoreU = ui->scoreP->intValue();


    scoreA = ui->scoreAI->intValue();

    QPropertyAnimation* animationA = new QPropertyAnimation(bouttonA, "geometry");
    QPropertyAnimation* animationP= new QPropertyAnimation(bouttonP, "geometry");
    int numberP = allCards[Index].getNumber();
    int numberA = allCards[Index+20].getNumber();
     if(numberP > numberA){
        if(numberA != 1){
            animationA->setStartValue(QRect(530, 200, 61, 81));
            animationA->setEndValue(QRect(270, 550, bouttonA->width(), bouttonA->height()));
            animationA->setDuration(1000);

            animationP->setStartValue(QRect(530, 320,61, 81));
            animationP->setEndValue(QRect(190,550, bouttonP->width(), bouttonP->height()));
            animationP->setDuration(1000);

            ui->scoreP->display(scoreU + 1);
        }else {
            animationA->setStartValue(QRect(530, 200, 61, 81));
            animationA->setEndValue(QRect(270, 30, bouttonA->width(), bouttonA->height()));
            animationA->setDuration(1000);

            animationP->setStartValue(QRect(530, 320,61, 81));
            animationP->setEndValue(QRect(190,30, bouttonP->width(), bouttonP->height()));
            animationP->setDuration(1000);

            ui->scoreAI->display(scoreA + 1);
        }

    }else if(numberA > numberP){
        if(numberP != 1){
            animationA->setStartValue(QRect(530, 200, 61, 81));
            animationA->setEndValue(QRect(270, 30, bouttonA->width(), bouttonA->height()));
            animationA->setDuration(1000);

            animationP->setStartValue(QRect(530, 320,61, 81));
            animationP->setEndValue(QRect(190,30, bouttonP->width(), bouttonP->height()));
            animationP->setDuration(1000);

            ui->scoreAI->display(scoreA + 1);

        } else {
            animationA->setStartValue(QRect(530, 200, 61, 81));
            animationA->setEndValue(QRect(270, 550, bouttonA->width(), bouttonA->height()));
            animationA->setDuration(1000);

            animationP->setStartValue(QRect(530, 320,61, 81));
            animationP->setEndValue(QRect(190,550, bouttonP->width(), bouttonP->height()));
            animationP->setDuration(1000);

            ui->scoreP->display(scoreU + 1);
        }

    } else{
        animationA->setStartValue(QRect(530, 200, 61, 81));
        animationA->setEndValue(QRect(920, 270, bouttonA->width(), bouttonA->height()));
        animationA->setDuration(1000);

        animationP->setStartValue(QRect(530, 320,61, 81));
        animationP->setEndValue(QRect(1000,270, bouttonP->width(), bouttonP->height()));
        animationP->setDuration(1000);
    }
    animationA->start();
    animationP->start();
    connect(animationA, &QPropertyAnimation::finished,this,[=]() {
        this->hide(bouttonA, bouttonP);
    });

}
void secondPage::hide(QPushButton* buttonA, QPushButton* buttonP){
    buttonA->setVisible(false);
    buttonP->setVisible(false);
}

void secondPage::bravo(){
    wiin->open();
}

void secondPage::gameOver(){
    lose->open();
}

void secondPage::tie(){
    Tie->open();
}
