#include "level.h"
#include "ui_level.h"
#include <QMainWindow>
#include <secondpage.h>

level::level(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::level)
{
    ui->setupUi(this);
    connect(ui->Pro,&QPushButton::clicked,this,[this]{
        level::buttonClick();
    });
    connect(ui->Amatteur,&QPushButton::clicked,this, &level::buttonClick);

}

level::~level()
{
    delete ui;
}

void level :: buttonClick(){
    secondPage * pageSuivante = new secondPage();
    pageSuivante->showMaximized();
    this->update();
}
