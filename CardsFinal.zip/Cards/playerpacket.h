#ifndef PLAYERPACKET_H
#define PLAYERPACKET_H

#include "card.h"
#include <QVector>
#include "player.h"
#include <QPushButton>

class PlayerPacket {
public:
    // Constructor
    PlayerPacket();
    // Function to draw a card from the player's packet
    Card drawCard();

    // Function to check if the player's packet is empty
    bool isEmpty() const;

    // Other functions as needed...

    void putInMiddle(QVector<Card> playerdef, QVector<Card> middle);
private:
    QVector<Card> cards;
    QVector<Card> inHand;

};

#endif // PLAYERPACKET_H

