#ifndef CARD_H
#define CARD_H
#include <QString>
#include <QPushButton>
#include <QObject>

class Card {
public:
    Card();
    Card(QString type, int card_num, QString path);
    Card(const Card& other);
    QString getType();
    int getNumber();
    QString getPath();
    QPushButton* getButton();
    Card& operator=(const Card& other);
private:
    QString type;
    int card_num;
    QString path;
};

#endif // CARD_H
